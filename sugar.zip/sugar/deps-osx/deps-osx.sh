# https://gist.github.com/quagliero/90f493f123c7b1ddba5428ba0146329a

brew install automake openssl zlib curl jansson make
